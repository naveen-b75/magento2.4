<?php
namespace Helloworld\Mymodule\Block;

class Helloworld extends \Magento\Framework\View\Element\Template{

    public function helloworld(){
        return "Hello World";
    }
}