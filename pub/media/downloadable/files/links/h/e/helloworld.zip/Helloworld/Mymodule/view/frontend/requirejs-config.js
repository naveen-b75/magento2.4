  var config={
    paths:{
        'myfile':'Helloworld_Mymodule/js/custom.js'
    },
      'shim':{
        'myfile':{
            deps:['jquery']
        }
      }
  };