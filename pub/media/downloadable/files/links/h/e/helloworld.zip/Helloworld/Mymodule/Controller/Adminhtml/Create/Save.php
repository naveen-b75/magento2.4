<?php
namespace Helloworld\Mymodule\Controller\Adminhtml\Create;

use Magento\Backend\App\Action\Context;
use Helloworld\Mymodule\Model\CurdFactory;

class Save extends \Magento\Backend\App\Action{
    protected $curdFactory;

    public function __construct(Context $context,CurdFactory $curdFactory)
    {
        $this->curdFactory=$curdFactory;
        parent::__construct($context);
    }

    public function execute()
    {
        $this->curdFactory->create()
            ->setData($this->getRequest()->getPostValue()['general'])
            ->save();
        return $this->resultRedirectFactory->create()->setPath('helloworld/index/index');
    }
}