<?php

namespace Helloworld\Mymodule\Block\Adminhtml;

class Helloworld extends \Magento\Framework\View\Element\Template{

    public function helloworld(){
        return "Hello World";
    }
}